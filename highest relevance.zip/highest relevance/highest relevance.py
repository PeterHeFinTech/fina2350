import pandas as pd
import os

print("==================================================")
print("⚙️ Executing Post-Processing: Highest Relevance Extraction")
print("==================================================")

# ==========================================
# 1. Load the Existing Raw Data
# ==========================================
input_csv = "nvda_sentiment_cat_c.csv" 

if not os.path.exists(input_csv):
    print(f"❌ Error: '{input_csv}' not found in the current directory.")
    exit()

try:
    df = pd.read_csv(input_csv)
    print(f"✅ Successfully loaded existing data containing {len(df)} news articles.")
except Exception as e:
    print(f"❌ Error reading the CSV file: {e}")
    exit()

# ==========================================
# 2. Isolate the Maximum Relevance Signal per Event
# ==========================================
print("🔍 Filtering for the purest Alpha signal (Highest NVDA Relevance) within each event...")

# Using .idxmax() to find the index of the row with the highest nvda_relevance for each event_date
idx = df.groupby('event_date')['nvda_relevance'].idxmax()

# Extract only those highest-scoring rows
df_best_signals = df.loc[idx].reset_index(drop=True)

# ==========================================
# 3. Format Output Headers
# ==========================================
# We select exactly the columns requested, dropping 'event_date' to match the final schema
final_headers = [
    "publish_date", 
    "title", 
    "source", 
    "nvda_relevance", 
    "nvda_sentiment_score", 
    "overall_sentiment_score", 
    "url", 
    "summary"
]

# Ensure all requested columns exist in the DataFrame before filtering
missing_cols = [col for col in final_headers if col not in df_best_signals.columns]
if missing_cols:
    print(f"⚠️ Warning: Missing columns in raw data: {missing_cols}")

# Reconstruct the DataFrame with strictly the requested columns
df_final = df_best_signals[final_headers]

# ==========================================
# 4. Export the Purified Dataset
# ==========================================
output_csv = "nvda_cat_c_highest_relevance_only.csv"
df_final.to_csv(output_csv, index=False, encoding='utf-8-sig')

print(f"\n🎉 Purification Complete!")
print(f"   Reduced {len(df)} raw articles down to {len(df_final)} core event signals.")
print(f"📁 Final aligned dataset saved to: {output_csv}")